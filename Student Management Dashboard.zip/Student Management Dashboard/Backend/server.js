const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");
const morgan = require("morgan");
const path = require("path");
const mongoose = require("mongoose");
const winston = require("winston");

require("winston-daily-rotate-file");

// Load environment variables
dotenv.config();

// Initialize Express app
const app = express();

// =============================
// 1. MIDDLEWARES
// =============================
app.use(cors());
app.use(express.json());

// Serve static frontend files (make sure "Frontend" folder exists)
app.use(express.static(path.join(__dirname, "..", "Frontend")));

// =============================
// 2. WINSTON LOGGER (ROTATING)
// =============================
const logDir = path.join(__dirname, "logs");

// Configure daily rotate transport
const dailyRotateTransport = new winston.transports.DailyRotateFile({
  filename: path.join(logDir, "combined-%DATE%.log"),
  datePattern: "YYYY-MM-DD",
  zippedArchive: true,
  maxSize: "10m",
  maxFiles: "14d", // Keep logs for 14 days
});

// Create logger instance
const logger = winston.createLogger({
  level: "info",
  format: winston.format.combine(
    winston.format.timestamp(),
    winston.format.json()
  ),
  transports: [
    new winston.transports.File({
      filename: path.join(logDir, "error.log"),
      level: "error",
    }),
    dailyRotateTransport,
    new winston.transports.Console({
      format: winston.format.combine(
        winston.format.colorize(),
        winston.format.simple()
      ),
    }),
  ],
});

// =============================
// 3. MORGAN REQUEST LOGGER
// =============================
app.use(
  morgan(":method :url :status :response-time ms - :res[content-length]", {
    stream: {
      write: (message) => logger.info(message.trim()),
    },
  })
);

// =============================
// 4. CONNECT TO MONGODB
// =============================
mongoose
  .connect(
    process.env.MONGODB_URI ||
      "mongodb://127.0.0.1:27017/student-management-app"
  )
  .then(() => logger.info("✅ Connected to MongoDB"))
  .catch((err) => {
    logger.error("❌ MongoDB connection error:", err);
    process.exit(1);
  });

// =============================
// 5. IMPORT ROUTES
// =============================
const studentRoutes = require("./routes/studentRoutes");
const courseRoutes = require("./routes/courseRoutes");
const dashboardRoutes = require("./routes/dashboardRoutes");

// =============================
// 6. USE ROUTES
// =============================
app.use("/api/students", studentRoutes);
app.use("/api/courses", courseRoutes);
app.use("/api/dashboard", dashboardRoutes);

// =============================
// 7. HEALTH CHECK ROUTES
// =============================

// Basic health check
app.get("/health", (req, res) => {
  res.status(200).json({
    status: "UP",
    timestamp: new Date(),
    environment: process.env.NODE_ENV || "development",
  });
});

// Detailed health check
app.get("/health/detailed", (req, res) => {
  const dbStatus =
    mongoose.connection.readyState === 1 ? "Connected" : "Disconnected";
  res.status(200).json({
    status: dbStatus === "Connected" ? "UP" : "DOWN",
    timestamp: new Date(),
    database: {
      status: dbStatus,
      name: "MongoDB",
      host: mongoose.connection.host,
    },
    system: {
      memory: {
        total: Math.round(process.memoryUsage().heapTotal / 1024 / 1024),
        used: Math.round(process.memoryUsage().heapUsed / 1024 / 1024),
        unit: "MB",
      },
      uptime: `${Math.floor(process.uptime())} seconds`,
      nodeVersion: process.version,
      platform: process.platform,
    },
    environment: process.env.NODE_ENV || "development",
  });
});

// =============================
// 8. GLOBAL ERROR HANDLER
// =============================
app.use((err, req, res, next) => {
  logger.error({
    message: err.message,
    stack: err.stack,
    method: req.method,
    path: req.path,
    params: req.params,
    query: req.query,
    body: req.method !== "GET" ? req.body : undefined,
  });

  res.status(500).json({ message: "Internal Server Error" });
});

// =============================
// 9. START SERVER
// =============================
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  logger.info(`🚀 Server running on http://localhost:${PORT}`);
});
