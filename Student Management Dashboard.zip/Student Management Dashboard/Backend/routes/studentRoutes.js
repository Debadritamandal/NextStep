const express = require("express");
const mongoose = require("mongoose");
const Student = require("../models/Student");
const Graduate = require("../models/Graduate");

const router = express.Router();

/**
 * GET /api/students
 * All students
 */
router.get("/", async (req, res) => {
  try {
    const students = await Student.find().sort({ createdAt: -1 });
    res.json(students);
  } catch (error) {
    console.error("Error fetching students:", error);
    res.status(500).json({ message: "Failed to fetch students" });
  }
});

/**
 * GET /api/students/search?q=...
 * 🔎 Search students by name/email/course (case-insensitive)
 * IMPORTANT: must be BEFORE "/:id"
 */
router.get("/search", async (req, res) => {
  try {
    const q = (req.query.q || "").trim();
    if (!q) return res.status(400).json({ message: "Search query is required" });

    const students = await Student.find({
      $or: [
        { name: { $regex: q, $options: "i" } },
        { email: { $regex: q, $options: "i" } },
        { course: { $regex: q, $options: "i" } },
      ],
    }).sort({ createdAt: -1 });

    res.json(students);
  } catch (error) {
    console.error("Error searching students:", error);
    res.status(500).json({ message: "Failed to search students" });
  }
});

/**
 * GET /api/students/graduates
 * 🎓 All graduates
 * IMPORTANT: must be BEFORE "/:id"
 */
router.get("/graduates", async (req, res) => {
  try {
    const graduates = await Graduate.find().sort({ graduationDate: -1 });
    res.json(graduates);
  } catch (error) {
    console.error("Error fetching graduates:", error);
    res.status(500).json({ message: "Failed to fetch graduates" });
  }
});

/**
 * GET /api/students/:id
 * Single student by id
 */
router.get("/:id", async (req, res) => {
  try {
    const { id } = req.params;
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(404).json({ message: "Student not found" });
    }
    const student = await Student.findById(id);
    if (!student) return res.status(404).json({ message: "Student not found" });
    res.json(student);
  } catch (error) {
    console.error("Error fetching student by ID:", error);
    res.status(500).json({ message: "Failed to fetch student" });
  }
});

/**
 * POST /api/students
 * Create student
 */
router.post("/", async (req, res) => {
  try {
    const student = new Student(req.body);
    const saved = await student.save();
    res.status(201).json(saved);
  } catch (error) {
    console.error("Error creating student:", error);
    res.status(400).json({ message: error.message || "Failed to create student" });
  }
});

/**
 * PUT /api/students/:id
 * Update student
 */
router.put("/:id", async (req, res) => {
  try {
    const { id } = req.params;
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(404).json({ message: "Student not found" });
    }
    const updated = await Student.findByIdAndUpdate(id, req.body, { new: true });
    if (!updated) return res.status(404).json({ message: "Student not found" });
    res.json(updated);
  } catch (error) {
    console.error("Error updating student:", error);
    res.status(400).json({ message: "Failed to update student" });
  }
});

/**
 * DELETE /api/students/:id
 * Delete student
 */
router.delete("/:id", async (req, res) => {
  try {
    const { id } = req.params;
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(404).json({ message: "Student not found" });
    }
    const deleted = await Student.findByIdAndDelete(id);
    if (!deleted) return res.status(404).json({ message: "Student not found" });
    res.json({ message: "Student deleted successfully" });
  } catch (error) {
    console.error("Error deleting student:", error);
    res.status(500).json({ message: "Failed to delete student" });
  }
});

/**
 * PUT /api/students/:id/graduate
 * Mark as graduated (+ store in Graduates collection if missing)
 */
router.put("/:id/graduate", async (req, res) => {
  try {
    const { id } = req.params;
    if (!mongoose.Types.ObjectId.isValid(id)) {
      return res.status(404).json({ message: "Student not found" });
    }

    const student = await Student.findById(id);
    if (!student) return res.status(404).json({ message: "Student not found" });

    student.status = "graduated";
    await student.save();

    const exists = await Graduate.findOne({ email: student.email });
    if (!exists) {
      await Graduate.create({
        name: student.name,
        email: student.email,
        course: student.course,
        enrollmentDate: student.enrollmentDate,
        graduationDate: new Date(),
      });
    }

    res.json({ message: "Student marked as graduated", student });
  } catch (error) {
    console.error("Error marking student as graduated:", error);
    res.status(500).json({ message: "Failed to mark as graduated" });
  }
});

module.exports = router;
