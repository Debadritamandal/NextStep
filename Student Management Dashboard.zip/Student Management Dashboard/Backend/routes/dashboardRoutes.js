const express = require("express");
const Student = require("../models/Student");  
const Course = require("../models/Course");  

const router = express.Router();

// GET dashboard stats
router.get("/stats", async (req, res) => {
  try {
    const totalStudents = await Student.countDocuments();
    const activeCourses = await Course.countDocuments({ status: "active" });
    const graduates = await Student.countDocuments({ status: "graduated" });

    // Calculate success rate
    const successRate =
      totalStudents > 0 ? Math.round((graduates / totalStudents) * 100) : 0;

    res.json({
      totalStudents,
      activeCourses,
      graduates,
      successRate,
    });
  } catch (error) {
    console.error("Error fetching dashboard stats:", error);
    res.status(500).json({ message: "Failed to fetch dashboard stats" });
  }
});

module.exports = router;
