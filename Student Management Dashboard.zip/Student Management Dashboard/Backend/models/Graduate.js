const mongoose = require("mongoose");

const graduateSchema = new mongoose.Schema(
  {
    name: { type: String, required: true },
    email: { type: String, required: true },
    course: { type: String, required: true },
    enrollmentDate: { type: Date, required: true },
    graduationDate: { type: Date, default: Date.now },
  },
  { timestamps: true }
);

module.exports = mongoose.model("Graduate", graduateSchema);
